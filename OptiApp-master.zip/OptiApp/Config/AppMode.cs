namespace OptiApp.Config;

public enum AppMode
{
    Test,
    Dist
}