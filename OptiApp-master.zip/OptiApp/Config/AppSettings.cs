using System.ComponentModel;

namespace OptiApp.Config;

public class AppSettings : INotifyPropertyChanged
{
    private AppMode _currentMode = AppMode.Test;

    public AppMode CurrentMode
    {
        get => _currentMode;
        set
        {
            if (_currentMode != value)
            {
                _currentMode = value;
                OnPropertyChanged(nameof(CurrentMode));
            }
        }
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}