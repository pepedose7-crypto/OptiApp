using OptiApp.Core;

namespace OptiApp.Features.RegistryTweaks;

public interface IRegistryTweaks : IFeature
{
    void ApplyTweak(string tweakFile);
    void RevertTweak(string tweakFile);
    IReadOnlyList<RegistryTweak> GetTweaks();
}