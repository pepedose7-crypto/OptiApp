using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using OptiApp.Config;

namespace OptiApp.Features.RegistryTweaks;

public class RegistryTweak
{
    public string Name { get; set; } = string.Empty;
    public string FilePath { get; set; } = string.Empty;
    public bool IsApplied { get; set; }
}

public class RegistryTweaksManager : IRegistryTweaks
{
    private readonly AppSettings _settings;
    private readonly List<RegistryTweak> _tweaks = new();
    private readonly string _backupFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "OptiApp", "RegBackups");

    public RegistryTweaksManager(AppSettings settings)
    {
        _settings = settings;
        Directory.CreateDirectory(_backupFolder);
        LoadCustomTweaks();
    }

    public string Name => "Registry Tweaks";

    public IReadOnlyList<RegistryTweak> Tweaks => _tweaks.AsReadOnly();

    private void LoadCustomTweaks()
    {
        string customTweaksDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "CustomTweaks");
        if (Directory.Exists(customTweaksDir))
        {
            foreach (var file in Directory.GetFiles(customTweaksDir, "*.reg"))
            {
                _tweaks.Add(new RegistryTweak
                {
                    Name = Path.GetFileNameWithoutExtension(file),
                    FilePath = file,
                    IsApplied = false
                });
            }
        }
    }

    public void ApplyTweak(string tweakFile)
    {
        if (_settings.CurrentMode == AppMode.Test)
        {
            // In test mode, just log
            return;
        }

        var tweak = _tweaks.FirstOrDefault(t => t.FilePath == tweakFile);
        if (tweak == null)
            return;

        // Backup current registry (simplified)
        string backupName = $"{tweak.Name}_backup_{DateTime.Now:yyyyMMdd_HHmmss}.reg";
        string backupPath = Path.Combine(_backupFolder, backupName);

        try
        {
            // Apply the tweak file using regedit
            var process = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = "regedit.exe",
                    Arguments = $"/s {tweakFile}",
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };

            process.Start();
            process.WaitForExit();

            tweak.IsApplied = true;

            // Save backup path for revert
            File.WriteAllText(backupPath, $"Registry tweak applied: {tweakFile}\nDate: {DateTime.Now}");
        }
        catch (Exception ex)
        {
            // Handle error silently
            _ = ex; // Suppress unused variable warning
        }
    }

    public void RevertTweak(string tweakFile)
    {
        if (_settings.CurrentMode == AppMode.Test)
        {
            return;
        }

        var tweak = _tweaks.FirstOrDefault(t => t.FilePath == tweakFile);
        if (tweak == null)
            return;

        tweak.IsApplied = false;
        // In real implementation, load and apply the backup
    }

    public void Initialize() { }
    public void Shutdown() { }

    public IReadOnlyList<RegistryTweak> GetTweaks() => _tweaks.AsReadOnly();
}