using System.Collections.ObjectModel;

namespace OptiApp.Features.Notifications;

public class OptiNotification
{
    public string Message { get; set; } = string.Empty;
    public NotificationType Type { get; set; } = NotificationType.Info;
    public DateTime Timestamp { get; set; } = DateTime.Now;
}

public enum NotificationType
{
    Info,
    Warning,
    Error,
    Success
}

public class NotificationSystem : INotificationSystem
{
    private readonly ObservableCollection<OptiNotification> _notifications = new();
    private System.Windows.Threading.DispatcherTimer? _autoHideTimer;

    public string Name => "OptiNotifications";
    public IReadOnlyList<OptiNotification> Notifications => _notifications.AsReadOnly();

    public NotificationSystem()
    {
        InitializeTimer();
    }

    private void InitializeTimer()
    {
        // Auto-hide notifications after 5 seconds (lightweight overlay concept)
        _autoHideTimer = new System.Windows.Threading.DispatcherTimer();
        _autoHideTimer.Interval = TimeSpan.FromSeconds(5);
        _autoHideTimer.Tick += (s, e) => AutoHideOldNotifications();
    }

    public void ShowNotification(string message, NotificationType type = NotificationType.Info)
    {
        var notification = new OptiNotification
        {
            Message = message,
            Type = type,
            Timestamp = DateTime.Now
        };

        _notifications.Add(notification);

        // Start auto-hide timer
        _autoHideTimer?.Start();
    }

    public void ShowNotification(string message)
    {
        ShowNotification(message, NotificationType.Info);
    }

    public void HideOverlay()
    {
        _notifications.Clear();
        _autoHideTimer?.Stop();
    }

    private void AutoHideOldNotifications()
    {
        var now = DateTime.Now;
        var oldNotifications = _notifications
            .Where(n => (now - n.Timestamp).TotalSeconds > 5)
            .ToList();

        foreach (var notification in oldNotifications)
        {
            _notifications.Remove(notification);
        }

        if (_notifications.Count == 0)
        {
            _autoHideTimer?.Stop();
        }
    }

    public void Initialize() { }
    public void Shutdown()
    {
        _autoHideTimer?.Stop();
        _autoHideTimer = null;
    }
}