using OptiApp.Core;

namespace OptiApp.Features.Notifications;

public interface INotificationSystem : IFeature
{
    void ShowNotification(string message);
    void HideOverlay();
}