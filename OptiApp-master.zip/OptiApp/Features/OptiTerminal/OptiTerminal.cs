using System.Collections.ObjectModel;

namespace OptiApp.Features.OptiTerminal;

public class CommandDefinition
{
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Action<string[]>? Execute { get; set; }
}

public class OptiTerminal : ITerminal
{
    private readonly ObservableCollection<string> _output = new();
    private readonly Dictionary<string, CommandDefinition> _commands = new();

    public string Name => "OptiTerminal";
    public IReadOnlyList<string> Output => _output.AsReadOnly();

    public OptiTerminal()
    {
        RegisterCommands();
    }

    private void RegisterCommands()
    {
        // Help command
        _commands["opti"] = new CommandDefinition
        {
            Name = "opti",
            Description = "Show all available commands",
            Execute = (args) => ShowHelp()
        };

        // Game boost command
        _commands["opti boostgame"] = new CommandDefinition
        {
            Name = "opti boostgame",
            Description = "Start game booster mode",
            Execute = (args) => ExecuteBoostGame(args)
        };

        // Clean cache command
        _commands["opti cleancache"] = new CommandDefinition
        {
            Name = "opti cleancache",
            Description = "Clean system cache (test/dist mode aware)",
            Execute = (args) => ExecuteCleanCache(args)
        };

        // Restore command
        _commands["opti restore"] = new CommandDefinition
        {
            Name = "opti restore",
            Description = "Restore system to normal state",
            Execute = (args) => ExecuteRestore(args)
        };

        // System info command
        _commands["opti sysinfo"] = new CommandDefinition
        {
            Name = "opti sysinfo",
            Description = "Show system information",
            Execute = (args) => ExecuteSysInfo(args)
        };

        // Clear screen
        _commands["clear"] = new CommandDefinition
        {
            Name = "clear",
            Description = "Clear terminal output",
            Execute = (args) => _output.Clear()
        };
    }

    public void ExecuteCommand(string command)
    {
        _output.Add($"> {command}");

        if (string.IsNullOrWhiteSpace(command))
            return;

        var parts = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length == 0)
            return;

        string cmdKey = parts.Length >= 2 ? $"{parts[0]} {parts[1]}" : parts[0];

        if (_commands.TryGetValue(cmdKey, out var cmd))
        {
            cmd.Execute?.Invoke(parts.Skip(2).ToArray());
        }
        else
        {
            _output.Add($"[ERROR] Unknown command: {command}");
        }
    }

    private void ShowHelp()
    {
        _output.Add("=== OptiApp Commands ===");
        foreach (var cmd in _commands.Values)
        {
            _output.Add($"  {cmd.Name,-20} - {cmd.Description}");
        }
    }

    private void ExecuteBoostGame(string[] args)
    {
        _output.Add("[INFO] Game Booster Mode activated");
        _output.Add("[INFO] Closing unnecessary processes...");
        _output.Add("[INFO] Setting process priorities...");
        _output.Add("[OK] Game Booster ready. Launch your game!");
    }

    private void ExecuteCleanCache(string[] args)
    {
        _output.Add("[INFO] Starting cache cleanup...");
        _output.Add("[INFO] Scanning temp files...");
        _output.Add("[INFO] Cleaning browser cache...");
        _output.Add("[OK] Cache cleaned successfully");
    }

    private void ExecuteRestore(string[] args)
    {
        _output.Add("[INFO] Restoring system...");
        _output.Add("[INFO] Restoring process priorities...");
        _output.Add("[INFO] Reopening closed applications...");
        _output.Add("[OK] System restored");
    }

    private void ExecuteSysInfo(string[] args)
    {
        _output.Add("=== System Information ===");
        _output.Add($"  OS: Windows");
        _output.Add($"  .NET: 8.0");
        _output.Add($"  App: OptiApp v1.0");
    }

    public string GetOutput()
    {
        return string.Join(Environment.NewLine, _output);
    }

    public void Initialize() { }
    public void Shutdown() { }
}