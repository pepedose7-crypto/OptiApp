using OptiApp.Core;

namespace OptiApp.Features.OptiTerminal;

public interface ITerminal : IFeature
{
    void ExecuteCommand(string command);
    string GetOutput();
}