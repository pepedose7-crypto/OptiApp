using System.Collections.ObjectModel;
using System.Diagnostics;

namespace OptiApp.Features.GameBooster;

public class Game
{
    public string Name { get; set; } = string.Empty;
    public string ExePath { get; set; } = string.Empty;
}

public class GameLibrary
{
    public ObservableCollection<Game> Games { get; } = new();

    public void AddGame(string name, string exePath)
    {
        Games.Add(new Game { Name = name, ExePath = exePath });
    }

    public void RemoveGame(Game game)
    {
        Games.Remove(game);
    }

    public void LaunchGame(Game game, IGameBooster booster)
    {
        try
        {
            booster.StartBoost(game.Name); // Assuming game.Name is process name or something
            Process.Start(new ProcessStartInfo
            {
                FileName = game.ExePath,
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            // Handle error
            Console.WriteLine($"Failed to launch game: {ex.Message}");
        }
    }
}