using System.Diagnostics;
using OptiApp.Core;
using OptiApp.Config;

namespace OptiApp.Features.GameBooster;

public class GameBooster : IGameBooster
{
    private readonly AppSettings _settings;
    private List<Process> _closedProcesses = new();

    public GameBooster(AppSettings settings)
    {
        _settings = settings;
    }

    public string Name => "Game Booster";

    public void Initialize()
    {
        // Initialize if needed
    }

    public void Shutdown()
    {
        StopBoost();
    }

    public void StartBoost(string gameProcessName)
    {
        if (_settings.CurrentMode == AppMode.Test)
        {
            // Mock boost
            return;
        }

        // Close unnecessary apps (example: close some common ones)
        var processesToClose = new[] { "notepad", "calc" }; // Placeholder
        foreach (var procName in processesToClose)
        {
            var processes = Process.GetProcessesByName(procName);
            foreach (var proc in processes)
            {
                try
                {
                    proc.CloseMainWindow();
                    _closedProcesses.Add(proc);
                }
                catch { }
            }
        }

        // Set game priority when process starts
        // For now, assume gameProcessName is the exe name
        // In real, monitor for process start
    }

    public void StopBoost()
    {
        if (_settings.CurrentMode == AppMode.Test)
        {
            return;
        }

        // Restore closed processes (restart them)
        foreach (var proc in _closedProcesses)
        {
            try
            {
                Process.Start(proc.StartInfo);
            }
            catch { }
        }
        _closedProcesses.Clear();

        // Restore priorities, etc.
    }
}