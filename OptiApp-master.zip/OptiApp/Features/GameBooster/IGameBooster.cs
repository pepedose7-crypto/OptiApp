using OptiApp.Core;

namespace OptiApp.Features.GameBooster;

public interface IGameBooster : IFeature
{
    void StartBoost(string gameProcessName);
    void StopBoost();
}