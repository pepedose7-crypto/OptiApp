@echo off
REM OptiApp Launcher Script
REM Automatically handles permissions and SmartScreen bypass

setlocal enabledelayedexpansion

echo.
echo ========================================
echo      OptiApp Windows Optimizer v1.0
echo ========================================
echo.

REM Check if running as administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo.
    echo [!] Admin privileges required for optimal performance.
    echo [*] Requesting elevation...
    echo.
    
    REM Re-run as administrator
    powershell -Command "Start-Process cmd -ArgumentList '/c %~s0' -Verb RunAs"
    exit /b
)

echo [OK] Running with admin privileges
echo.

REM Get the directory where this script is located
set SCRIPT_DIR=%~dp0
set APP_EXE=%SCRIPT_DIR%OptiApp.exe

REM Check if OptiApp.exe exists
if not exist "%APP_EXE%" (
    echo [ERROR] OptiApp.exe not found at: %APP_EXE%
    echo.
    echo Please ensure OptiApp.exe is in the same directory as this script.
    pause
    exit /b 1
)

echo [*] Launching OptiApp...
echo [*] Executable: %APP_EXE%
echo.

REM Unblock the file (removes SmartScreen warning on Windows 10/11)
powershell -Command "Unblock-File -Path '%APP_EXE%'" >nul 2>&1

REM Launch the application
start "" "%APP_EXE%"

echo [OK] OptiApp launched successfully!
echo.
echo Press any key to close this window...
pause >nul
exit /b 0
