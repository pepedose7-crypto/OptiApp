﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using OptiApp.UI;
using OptiApp.Core;
using OptiApp.Config;
using OptiApp.Features.GameBooster;

namespace OptiApp;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    private readonly MainViewModel _viewModel;
    private readonly GameBooster _gameBooster;

    public MainWindow()
    {
        InitializeComponent();

        var settings = new AppSettings();
        var monitor = new SystemMonitor();
        _viewModel = new MainViewModel(monitor, settings);
        _gameBooster = new GameBooster(settings);
        DataContext = _viewModel;

        // Update stats periodically (placeholder)
        _viewModel.UpdateStats();
    }

    private void AddGameButton_Click(object sender, RoutedEventArgs e)
    {
        string name = GameNameTextBox.Text;
        string path = GamePathTextBox.Text;
        if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(path))
        {
            _viewModel.GameLibrary.AddGame(name, path);
            GameNameTextBox.Clear();
            GamePathTextBox.Clear();
        }
    }

    private void LaunchGameButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button button && button.Tag is Game game)
        {
            _viewModel.GameLibrary.LaunchGame(game, _gameBooster);
        }
    }

    private void RemoveGameButton_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button button && button.Tag is Game game)
        {
            _viewModel.GameLibrary.RemoveGame(game);
        }
    }
}