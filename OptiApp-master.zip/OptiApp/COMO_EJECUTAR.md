# OptiApp - Guía de Ejecución para Windows 10/11

## 📋 Requisitos del Sistema

- **OS**: Windows 10 (Build 19041+) o Windows 11
- **Arquitectura**: 64-bit (x64)
- **.NET Runtime**: Incluido (no requiere instalación)
- **RAM**: 2GB mínimo
- **Derechos**: Admin recomendado para Game Booster y Registry Tweaks

## 🚀 Formas de Ejecutar

### Opción 1: Ultra Rápido (Recomendado)
```
Doble-click en: START.bat
```
- ⚡ Más rápido
- 🔓 Desbloquea automáticamente el archivo
- ✨ Ejecuta OptiApp directamente

### Opción 2: Con Permisos Admin
```
Doble-click en: START_ADMIN.bat
```
- 🔐 Solicita permisos admin automáticamente
- 🎮 Recomendado para Game Booster
- 🔧 Necesario para Registry Tweaks

### Opción 3: Ejecución Estándar
```
Doble-click en: OptiApp.exe directamente
```
- Sin soporte de admin automático
- Puede aparecer warning de SmartScreen (Windows Security)

## ⚠️ Si Aparece "Windows Protegió tu PC"

**Haz esto:**
1. Haz click en "Más información" (More info)
2. Haz click en "Ejecutar de todas formas" (Run anyway)
3. ¡La app se abrirá!

**O:**
1. Usa el script `START.bat` - desbloquea automáticamente

## 🛡️ Desbloqueando el Archivo Manualmente

Si tienes problemas, abre PowerShell como Admin:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
Unblock-File -Path "C:\ruta\a\OptiApp.exe"
```

Luego ejecuta:
```
./OptiApp.exe
```

## ❓ Preguntas Frecuentes

### P: ¿Por qué aparece un warning?
R: Windows 10/11 están siendo cautelosos porque es un app desconocido. Es completamente seguro.

### P: ¿Necesito admin para todo?
R: 
- ❌ **NO** para: Dashboard, Game Library, Terminal, Notifications
- ✅ **SÍ** para: Game Booster, Registry Tweaks, Clean Cache

### P: ¿Funciona en Windows 10?
R: **SÍ**, completamente compatible desde Build 19041 en adelante

### P: ¿Funciona en Windows 11?
R: **SÍ**, totalmente soportado

### P: El script .bat no funciona
R: Intenta:
1. Coloca OptiApp.exe en la misma carpeta que el .bat
2. Haz click derecho en el .bat → Ejecutar como administrador
3. Si aún no funciona, ejecuta OptiApp.exe directamente

## 📦 Estructura de Carpetas

```
OptiApp/
├── OptiApp.exe              ← Aplicación principal
├── START.bat                ← Script rápido (sin admin)
├── START_ADMIN.bat          ← Script con admin
├── RUN_OPTIAPP.bat          ← Script con más opciones
├── CustomTweaks/            ← Tweaks personalizados del usuario
└── (archivos de soporte .dll)
```

## 🔧 Troubleshooting

| Problema | Solución |
|----------|----------|
| "Windows protected your PC" | Usa START.bat o click "Run anyway" |
| App no inicia | Ejecuta como admin (START_ADMIN.bat) |
| Error de permisos | Necesitas admin para Registry Tweaks |
| App lenta | Normal en PCs bajos, diseñada para ser ligera |

## 💡 Tips

1. **Pin a Inicio**: Arrastra START.bat a la carpeta Startup
2. **Acceso rápido**: Crea un atajo en el Escritorio
3. **Modo Test**: Úsalo primero para aprender
4. **Modo Dist**: Usa cuando estés seguro

## 📞 Soporte

- Windows 10/11: ✅ Totalmente soportado
- Windows 7/8: ❌ No soportado (requiere .NET 8.0)

¡Disfrutá OptiApp! 🚀
