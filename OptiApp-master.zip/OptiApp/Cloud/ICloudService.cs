namespace OptiApp.Cloud;

public interface ICloudService
{
    // Placeholder methods for future cloud integration
    Task<bool> SyncSettingsAsync();
    Task<bool> UploadDataAsync(string data);
    Task<string?> DownloadDataAsync();
}