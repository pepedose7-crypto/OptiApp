using System.Diagnostics;
using System.Management;

namespace OptiApp.Core;

public class SystemMonitor
{
    public double GetCpuUsage()
    {
        // Placeholder for CPU usage - in real impl, use PerformanceCounter
        return 0.0;
    }

    public double GetRamUsage()
    {
        // Placeholder for RAM usage
        return 0.0;
    }

    public string GetGpuInfo()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_VideoController");
            foreach (ManagementObject obj in searcher.Get())
            {
                return obj["Name"]?.ToString() ?? "Unknown GPU";
            }
        }
        catch
        {
            return "GPU detection failed";
        }
        return "No GPU found";
    }

    public long GetTotalRam()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_ComputerSystem");
            foreach (ManagementObject obj in searcher.Get())
            {
                return Convert.ToInt64(obj["TotalPhysicalMemory"]) / (1024 * 1024); // MB
            }
        }
        catch
        {
            return 0;
        }
        return 0;
    }

    public long GetStorageInfo()
    {
        try
        {
            using var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_LogicalDisk WHERE DriveType=3");
            long total = 0;
            foreach (ManagementObject obj in searcher.Get())
            {
                total += Convert.ToInt64(obj["Size"]) / (1024 * 1024 * 1024); // GB
            }
            return total;
        }
        catch
        {
            return 0;
        }
    }

    // Add more methods as needed
}