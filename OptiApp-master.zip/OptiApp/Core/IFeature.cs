namespace OptiApp.Core;

public interface IFeature
{
    string Name { get; }
    void Initialize();
    void Shutdown();
}