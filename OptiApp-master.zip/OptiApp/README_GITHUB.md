# OptiApp - Windows Optimization Tool

![Version](https://img.shields.io/badge/Version-1.0.0-blue.svg)
![Platform](https://img.shields.io/badge/Platform-Windows%2010%2F11-0078D4.svg)
![License](https://img.shields.io/badge/License-Proprietary-red.svg)

## 🎯 Overview

**OptiApp** is a comprehensive Windows optimization application built with C# .NET 8.0 and WPF. It provides real-time system monitoring, game optimization, registry tweaks, and system terminal capabilities for Windows 10 and Windows 11.

## ✨ Key Features

### 📊 System Dashboard
- Real-time CPU usage monitoring
- RAM memory tracking
- GPU information display
- Storage capacity overview
- System health indicators

### 🎮 Game Booster
- Automatically optimize games for performance
- Close unnecessary background applications
- Manage process priorities
- Build and manage game library
- Launch games directly from OptiApp

### 🖥️ OptiTerminal
- Custom system commands
- Cache cleaning utilities
- System settings restoration
- System information retrieval
- Real-time command output display

### ⚙️ Registry Tweaks
- Apply Windows optimization tweaks
- Backup and restore functionality
- Manage custom .reg files
- Safe registry modifications with rollback

### 🔔 Notifications System
- Real-time system notifications
- Success, warning, error, and info types
- Auto-dismissing overlays
- Non-intrusive notifications

## 🛠️ Technical Stack

- **Language**: C# .NET 8.0
- **UI Framework**: WPF (Windows Presentation Foundation)
- **Target OS**: Windows 10 (Build 19041+) & Windows 11
- **Architecture**: MVVM (Model-View-ViewModel)
- **Pattern**: Modular feature-based design
- **Build**: Self-contained executable (no .NET installation required)

## 📋 System Requirements

| Requirement | Specification |
|---|---|
| OS | Windows 10 (Build 19041+) or Windows 11 |
| Architecture | x64 (64-bit) |
| RAM | 2 GB minimum |
| Disk Space | 300 MB available |
| .NET Runtime | Included (self-contained) |

## 🚀 Quick Start

### Option 1: Using Distribution Package (Recommended)

1. Download `OptiApp-v1.0.0.zip` from [Releases](../../releases)
2. Extract the ZIP file
3. Double-click `RUN_OPTIAPP.bat`
4. Allow Windows UAC prompt if requested
5. Enjoy optimizing!

### Option 2: Build from Source

```bash
# Clone the repository
git clone https://github.com/pepedose7-crypto/OptiApp.git
cd OptiApp

# Build Release version
dotnet build -c Release

# Publish as self-contained executable
dotnet publish -r win-x64 -c Release --self-contained /p:PublishSingleFile=true

# Run the application
.\bin\Release\net8.0-windows\win-x64\publish\OptiApp.exe
```

## 📂 Project Structure

```
OptiApp/
├── Core/                          # Core functionality
│   └── FeatureBase.cs            # Base class for features
├── Features/                      # Feature modules
│   ├── GameBooster/              # Game optimization
│   │   ├── GameBooster.cs
│   │   ├── GameLibrary.cs
│   │   └── IGameBooster.cs
│   ├── OptiTerminal/             # Custom terminal
│   │   ├── OptiTerminal.cs
│   │   └── ITerminal.cs
│   ├── RegistryTweaks/           # Registry management
│   │   ├── RegistryTweaksManager.cs
│   │   └── IRegistryTweaks.cs
│   ├── Notifications/            # Notification system
│   │   ├── NotificationSystem.cs
│   │   └── INotificationSystem.cs
│   └── IFeature.cs               # Feature interface
├── UI/                            # User Interface
│   ├── MainWindow.xaml           # Main application window
│   ├── MainViewModel.cs          # MVVM ViewModel
│   ├── TerminalView.xaml         # Terminal tab
│   ├── TweaksView.xaml           # Tweaks tab
│   └── Views/                    # Additional views
├── Themes/                        # UI Themes
│   └── ModernTheme.xaml          # Dark theme styling
├── Config/                        # Configuration
│   ├── AppConfig.cs              # App configuration
│   └── Constants.cs              # Application constants
├── Cloud/                         # Cloud features (placeholder)
│   └── CloudSync.cs              # Cloud synchronization
├── Launcher/                      # Batch launchers
│   ├── RUN_OPTIAPP.bat          # Main launcher
│   ├── START.bat                 # Quick launcher
│   └── START_ADMIN.bat           # Admin launcher
├── OptiApp.csproj               # Project configuration
├── App.xaml                      # Application resources
├── App.xaml.cs                  # Application code-behind
├── MainWindow.xaml              # Main window
└── MainWindow.xaml.cs           # Main window code-behind
```

## 🎨 UI Features

- **Dark Theme**: Modern dark interface with green accents
- **4-Tab Layout**: Dashboard | Games | Terminal | Tweaks
- **Real-time Monitoring**: Live system statistics
- **Color-coded Information**: Easy-to-read status indicators
- **Responsive Design**: Adapts to 1000x700px minimum window

## 🔐 Security & Safety

✅ **What OptiApp includes:**
- SmartScreen bypass via legitimate PowerShell unblocking
- Automatic admin privilege detection
- Registry backup before modifications
- Reversible system changes
- Local operation only (no cloud upload)
- Self-contained executable

❌ **What OptiApp doesn't do:**
- Disable Windows security features
- Upload personal data
- Install hidden services
- Modify system outside app scope
- Download external code

## 🚀 Launcher Scripts

### RUN_OPTIAPP.bat
- **Purpose**: Main recommended launcher
- **Features**: Admin detection, SmartScreen bypass, error handling
- **Usage**: `RUN_OPTIAPP.bat`

### START.bat
- **Purpose**: Quick launcher
- **Features**: Minimal overhead, fast execution
- **Usage**: `START.bat`

### START_ADMIN.bat
- **Purpose**: Force admin privileges
- **Features**: Automatic UAC elevation
- **Usage**: `START_ADMIN.bat`

## 📋 Build Information

```
Build Configuration: Release
Framework: .NET 8.0 (.NET/C#)
Platform: win-x64 (64-bit)
Executable Size: ~147 MB (self-contained)
Distribution Package: ~63 MB (ZIP compressed)
Compilation Time: ~2.5 seconds
Publish Time: ~10 seconds
```

## 🔧 Building from Source

### Prerequisites

- Visual Studio 2022 or Visual Studio Code
- .NET 8.0 SDK or later
- Windows 10/11 development environment

### Build Steps

```bash
# Clean previous builds
dotnet clean

# Restore dependencies
dotnet restore

# Build Debug version
dotnet build -c Debug

# Build Release version
dotnet build -c Release

# Publish as standalone executable
dotnet publish -r win-x64 -c Release --self-contained /p:PublishSingleFile=true
```

### Output Location

```
bin/Release/net8.0-windows/win-x64/publish/OptiApp.exe
```

## 📦 Distribution

### Download Pre-built Package

1. Go to [Releases](../../releases)
2. Download `OptiApp-v1.0.0.zip`
3. Extract to desired location
4. Run `RUN_OPTIAPP.bat`

### Create Your Own Build

```bash
# After building, files are in:
# bin/Release/net8.0-windows/win-x64/publish/

# Package for distribution:
tar -czf OptiApp-v1.0.0.tar.gz bin/Release/net8.0-windows/win-x64/publish/
```

## 🌐 Supported Languages

- English (en-US)
- Spanish (es-ES)
- German (de-DE)
- French (fr-FR)
- Italian (it-IT)
- Portuguese (pt-BR)
- Russian (ru-RU)
- Polish (pl-PL)
- Turkish (tr-TR)
- Japanese (ja-JP)
- Korean (ko-KR)
- Chinese Simplified (zh-Hans)
- Chinese Traditional (zh-Hant)
- Czech (cs-CZ)

*Language automatically detected from Windows system settings*

## 🤝 Contributing

Contributions are welcome! Please feel free to:
- Report issues
- Suggest features
- Submit pull requests
- Improve documentation

## 📝 License

This project is proprietary software. All rights reserved.

## 📞 Support

For issues, questions, or suggestions:
1. Check existing [Issues](../../issues)
2. Review [Documentation](./HOW_TO_RUN.md)
3. Check Spanish guide: [COMO_EJECUTAR.md](./COMO_EJECUTAR.md)

## 🙏 Acknowledgments

- Built with .NET 8.0 and WPF
- Windows optimization best practices
- Community feedback and suggestions

## 📊 Project Status

**Version**: 1.0.0  
**Status**: Production Ready ✓  
**Last Updated**: April 5, 2026  
**Platform Support**: Windows 10 Build 19041+, Windows 11

---

**Ready to optimize your Windows system?** Download the latest release and run `RUN_OPTIAPP.bat` to get started! 🚀
