using System.Collections.ObjectModel;
using System.ComponentModel;
using OptiApp.Config;
using OptiApp.Core;
using OptiApp.Features.GameBooster;
using OptiApp.Features.OptiTerminal;
using OptiApp.Features.RegistryTweaks;
using OptiApp.Features.Notifications;

namespace OptiApp.UI;

public class MainViewModel : INotifyPropertyChanged
{
    private readonly SystemMonitor _monitor;
    private readonly AppSettings _settings;
    public GameLibrary GameLibrary { get; } = new();
    public OptiTerminal Terminal { get; }
    public RegistryTweaksManager TweaksManager { get; }
    public NotificationSystem NotificationSystem { get; }

    public MainViewModel(SystemMonitor monitor, AppSettings settings)
    {
        _monitor = monitor;
        _settings = settings;
        ActiveOptimizations = new ObservableCollection<string>();
        Terminal = new OptiTerminal();
        TweaksManager = new RegistryTweaksManager(settings);
        NotificationSystem = new NotificationSystem();
    }

    private double _cpuUsage;
    public double CpuUsage
    {
        get => _cpuUsage;
        set
        {
            _cpuUsage = value;
            OnPropertyChanged(nameof(CpuUsage));
        }
    }

    private double _ramUsage;
    public double RamUsage
    {
        get => _ramUsage;
        set
        {
            _ramUsage = value;
            OnPropertyChanged(nameof(RamUsage));
        }
    }

    private string _gpuInfo = string.Empty;
    public string GpuInfo
    {
        get => _gpuInfo;
        set
        {
            _gpuInfo = value;
            OnPropertyChanged(nameof(GpuInfo));
        }
    }

    private long _totalRam;
    public long TotalRam
    {
        get => _totalRam;
        set
        {
            _totalRam = value;
            OnPropertyChanged(nameof(TotalRam));
        }
    }

    private long _storageInfo;
    public long StorageInfo
    {
        get => _storageInfo;
        set
        {
            _storageInfo = value;
            OnPropertyChanged(nameof(StorageInfo));
        }
    }

    public ObservableCollection<string> ActiveOptimizations { get; }

    public AppMode CurrentMode => _settings.CurrentMode;

    public void ExecuteTerminalCommand(string command)
    {
        Terminal.ExecuteCommand(command);
    }

    public void UpdateStats()
    {
        CpuUsage = _monitor.GetCpuUsage();
        RamUsage = _monitor.GetRamUsage();
        GpuInfo = _monitor.GetGpuInfo();
        TotalRam = _monitor.GetTotalRam();
        StorageInfo = _monitor.GetStorageInfo();
    }

    public event PropertyChangedEventHandler? PropertyChanged;

    protected virtual void OnPropertyChanged(string propertyName)
    {
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
}