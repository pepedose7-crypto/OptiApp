using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace OptiApp.UI;

public partial class TerminalView : UserControl
{
    public TerminalView()
    {
        InitializeComponent();
    }

    private void CommandInput_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Return)
        {
            ExecuteCommand();
            e.Handled = true;
        }
    }

    private void ExecuteButton_Click(object sender, RoutedEventArgs e)
    {
        ExecuteCommand();
    }

    private void ExecuteCommand()
    {
        string command = CommandInput.Text;
        if (string.IsNullOrWhiteSpace(command))
            return;

        if (DataContext is MainViewModel viewModel)
        {
            viewModel.ExecuteTerminalCommand(command);
            CommandInput.Clear();
            CommandInput.Focus();
        }
    }
}