using System.Windows;
using System.Windows.Controls;
using OptiApp.Features.RegistryTweaks;

namespace OptiApp.UI;

public partial class TweaksView : UserControl
{
    public TweaksView()
    {
        InitializeComponent();
    }

    private void ApplyTweak_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button button && button.Tag is RegistryTweak tweak)
        {
            if (DataContext is MainViewModel viewModel)
            {
                viewModel.TweaksManager.ApplyTweak(tweak.FilePath);
                MessageBox.Show($"Tweak '{tweak.Name}' applied!", "Registry Tweaks", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }

    private void RevertTweak_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button button && button.Tag is RegistryTweak tweak)
        {
            if (DataContext is MainViewModel viewModel)
            {
                viewModel.TweaksManager.RevertTweak(tweak.FilePath);
                MessageBox.Show($"Tweak '{tweak.Name}' reverted!", "Registry Tweaks", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}