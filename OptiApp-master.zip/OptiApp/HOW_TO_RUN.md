# OptiApp - Windows 10/11 Execution Guide

## 📋 System Requirements

- **OS**: Windows 10 (Build 19041+) or Windows 11
- **Architecture**: 64-bit (x64)
- **.NET Runtime**: Included (no installation needed)
- **RAM**: 2GB minimum
- **Permissions**: Admin recommended for Game Booster and Registry Tweaks

## 🚀 How to Run

### Option 1: Quick Start (Recommended)
```
Double-click: START.bat
```
- ⚡ Fastest
- 🔓 Auto-unblocks file
- ✨ Launches OptiApp directly

### Option 2: With Admin Privileges
```
Double-click: START_ADMIN.bat
```
- 🔐 Auto-requests admin permissions
- 🎮 Recommended for Game Booster
- 🔧 Required for Registry Tweaks

### Option 3: Direct Execution
```
Double-click: OptiApp.exe directly
```
- No auto admin support
- May show SmartScreen warning

## ⚠️ If "Windows Protected Your PC" Appears

**Do this:**
1. Click "More info"
2. Click "Run anyway"
3. App will launch!

**Or:**
1. Use `START.bat` script - auto-unblocks

## 🛡️ Manually Unblocking

Open PowerShell as Admin:

```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
Unblock-File -Path "C:\path\to\OptiApp.exe"
```

Then run:
```
./OptiApp.exe
```

## ❓ FAQ

### Q: Why is there a warning?
A: Windows 10/11 is being cautious about unknown apps. It's completely safe.

### Q: Do I need admin for everything?
A: 
- ❌ **NO** for: Dashboard, Game Library, Terminal, Notifications
- ✅ **YES** for: Game Booster, Registry Tweaks, Clean Cache

### Q: Does it work on Windows 10?
A: **YES**, fully compatible from Build 19041 onwards

### Q: Does it work on Windows 11?
A: **YES**, fully supported

### Q: The script won't work
A: Try:
1. Ensure OptiApp.exe is in same folder as .bat
2. Right-click .bat → Run as administrator
3. If still fails, run OptiApp.exe directly

## 📦 Folder Structure

```
OptiApp/
├── OptiApp.exe              ← Main application
├── START.bat                ← Quick script (no admin)
├── START_ADMIN.bat          ← Script with admin
├── RUN_OPTIAPP.bat          ← Full featured script
├── CustomTweaks/            ← User custom tweaks
└── (support .dll files)
```

## 🔧 Troubleshooting

| Issue | Solution |
|-------|----------|
| "Windows protected your PC" | Use START.bat or click "Run anyway" |
| App won't start | Run as admin (START_ADMIN.bat) |
| Permission errors | Need admin for Registry Tweaks |
| App slow | Normal on low-end PC, optimized for minimal usage |

## 💡 Tips

1. **Pin to Start**: Drag START.bat to Startup folder
2. **Desktop Shortcut**: Create shortcut on Desktop
3. **Test Mode First**: Use to learn features
4. **Dist Mode**: Use when confident

## 📞 Support

- Windows 10/11: ✅ Fully supported
- Windows 7/8: ❌ Not supported (requires .NET 8.0)

Enjoy OptiApp! 🚀
