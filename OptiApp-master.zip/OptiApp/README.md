# OptiApp - Windows Optimization Tool

A lightweight, powerful optimization app for low-end PCs with modular features for gaming, system tweaking, and performance monitoring.

## Features

### 🎮 Game Booster Mode
- Detect when a game process starts
- Automatically close unnecessary background apps
- Set game process priority to high
- Restore everything after game closes
- **Test Mode**: No real changes (for safety)
- **Dist Mode**: Apply real optimizations

### 🖥️ OptiTerminal
Custom lightweight terminal with:
- Real-time CPU/RAM stats display
- Custom command system:
  - `opti` - Show all commands
  - `opti boostgame` - Start game booster
  - `opti cleancache` - Clean system cache
  - `opti restore` - Restore system state
  - `opti sysinfo` - Show system info
  - `clear` - Clear terminal output
- No memory-heavy dependencies
- Minimal animations for low-end PCs

### ⚙️ Registry Tweaks System
- Load and execute .reg files
- Support custom user scripts from `CustomTweaks/` folder
- Backup registry before applying changes
- Revert option for all tweaks
- **Example tweaks provided:**
  - `EnableHWAccel.reg` - Hardware acceleration
  - `NetworkOptimization.reg` - Gaming network optimization

### 🔔 OptiNotifications
- Mock notification system (WIP for real API integration)
- Lightweight overlay display
- Auto-hide after 5 seconds
- Non-intrusive during gaming

### 📊 Dashboard
- Real-time system monitoring:
  - CPU Usage
  - RAM Usage (Total & Current)
  - GPU Information
  - Storage Capacity
- Active optimizations list
- Feature quick-access buttons

### 🎮 Game Library
- Add/Remove games easily
- Store game .exe paths
- One-click launch with automatic Game Booster activation
- Persistent game list (JSON support - WIP)

## System Requirements

- **OS**: Windows 10 or later
- **RAM**: 2GB minimum (optimized for 8GB)
- **CPU**: Any (optimized for low-end like AMD E1)
- **.NET**: Runtime 8.0+

## Installation & Usage

1. **Download**: Get `OptiApp.exe` from releases
2. **Extract**: No installation required (portable)
3. **Run**: Execute `OptiApp.exe`
4. **Select Mode**:
   - **Test Mode**: Safe testing (no system changes)
   - **Dist Mode**: Real optimizations (be careful!)

## UI Tabs

1. **Dashboard** - System stats and quick features
2. **Game Library** - Manage your games
3. **OptiTerminal** - Command interface
4. **Registry Tweaks** - Apply system optimizations

## Example Commands

```
> opti
=== OptiApp Commands ===
  opti                 - Show all commands
  opti boostgame       - Start game booster mode
  opti cleancache      - Clean system cache (test/dist mode aware)
  opti restore         - Restore system to normal state
  opti sysinfo         - Show system information
  clear                - Clear terminal output

> opti boostgame
[INFO] Game Booster Mode activated
[INFO] Closing unnecessary processes...
[INFO] Setting process priorities...
[OK] Game Booster ready. Launch your game!
```

## Adding Custom Tweaks

1. Create a `.reg` file in the `CustomTweaks/` folder
2. Restart OptiApp (it auto-detects new files)
3. Go to **Registry Tweaks** tab
4. Click **Apply** for your custom tweak

### Example Custom Tweak Template:
```reg
Windows Registry Editor Version 5.00

[HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters]
"MyCustomValue"=dword:00000001
```

## Modes Explained

### Test Mode
- ✅ Full UI interaction
- ✅ Terminal commands execute
- ❌ **NO real system changes**
- Perfect for learning and testing

### Dist Mode (Distribution/Production)
- ✅ All features enabled
- ✅ Real system modifications
- ✅ Registry tweaks apply
- ✅ Process management active
- ⚠️ **Use with caution - makes real changes**

## Architecture

```
OptiApp/
├── Core/               # Core logic (SystemMonitor, IFeature)
├── Features/
│   ├── GameBooster/    # Game optimization
│   ├── OptiTerminal/   # Custom terminal
│   ├── RegistryTweaks/ # Registry system
│   └── Notifications/  # Notification layer
├── UI/                 # WPF UI components
├── Config/             # Settings & modes
├── Cloud/              # Cloud integration (WIP)
├── CustomTweaks/       # User registry files
└── Data/               # Data storage
```

## Performance Tips

- **Use Test Mode first** to understand features
- **Close background apps** before games for best results
- **Custom tweaks** should be tested on secondary systems first
- **Monitor temps** while gaming (use external tools)

## Cloud Features (WIP)

Future integration planned for:
- Firebase Firestore (settings sync)
- Firebase Storage (backup/restore)
- OwnCloud support (self-hosted)
- Game performance profiles sharing

Currently only placeholder interfaces exist.

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Registry tweaks don't apply | Switch to Dist mode & run as admin |
| Terminal commands not working | Check syntax with `opti` command |
| Game Booster doesn't detect game | Add game to library manually |
| App crashes on startup | Check .NET 8.0 is installed |

## Future Roadmap

- [ ] Real-time CPU/RAM monitoring (replace placeholders)
- [ ] Game auto-detection
- [ ] Cloud sync integration
- [ ] Custom command scripting
- [ ] Process management UI
- [ ] System cache cleaning
- [ ] Disk cleanup tools
- [ ] Startup program manager

## License

OpenSource - Use and modify freely

## Support

For issues or feature requests, create an issue or pull request.

---

**Version**: 1.0  
**Last Updated**: April 5, 2026  
**Built with**: C# .NET 8.0 WPF
