@echo off
REM Fast startup script for OptiApp
REM Double-click this to run OptiApp with admin privileges

cd /d "%~dp0"
powershell -Command "Unblock-File -Path '.\OptiApp.exe'" 2>nul
start OptiApp.exe
