@echo off
REM OptiApp GitHub Push Script
REM Este script sube el repositorio a GitHub

echo.
echo ====================================
echo   OptiApp - GitHub Push Script
echo ====================================
echo.

REM Check if git is installed
where git >nul 2>nul
if %errorlevel% neq 0 (
    echo Error: Git no está instalado o no está en PATH
    echo Descarga Git desde: https://git-scm.com/download/win
    pause
    exit /b 1
)

REM Navigate to OptiApp directory
set OPTIAPP_DIR=%~dp0
cd /d "%OPTIAPP_DIR%"

echo Directorio: %cd%
echo.

REM Check if repository exists
git rev-parse --git-dir >nul 2>nul
if %errorlevel% neq 0 (
    echo Error: No es un repositorio Git válido
    pause
    exit /b 1
)

echo ✓ Repositorio Git detectado
echo.

REM Show current remote
echo Remote configurado:
git remote -v
echo.

REM Check for uncommitted changes
git diff-index --quiet HEAD --
if %errorlevel% neq 0 (
    echo Cambios sin commitear detectados
    echo Realizando commit automático...
    git add -A
    git commit -m "Update: Changes before GitHub push"
)

echo.
echo Preparado para hacer push a GitHub...
echo.

REM Instructions
echo ====================================
echo   INSTRUCCIONES DE PUSH
echo ====================================
echo.
echo 1. Si aún no has creado el repositorio en GitHub:
echo    a. Ve a: https://github.com/new
echo    b. Nombre: OptiApp
echo    c. Haz clic en "Create repository"
echo.
echo 2. Ejecuta este comando en PowerShell o CMD:
echo.
echo    git push -u origin main
echo.
echo 3. O usa este comando simplificado:
echo.

REM Try to push
echo Intentando hacer push...
git push -u origin main
if %errorlevel% equ 0 (
    echo.
    echo ====================================
    echo   ✓ PUSH EXITOSO
    echo ====================================
    echo.
    echo Tu repositorio está en:
    echo https://github.com/pepedose7-crypto/OptiApp
    echo.
    pause
) else (
    echo.
    echo ====================================
    echo   ✗ ERROR EN PUSH
    echo ====================================
    echo.
    echo Posibles soluciones:
    echo 1. El repositorio no existe en GitHub (crea uno primero)
    echo 2. Token de autenticación inválido o sin permisos
    echo 3. Conexión a Internet no disponible
    echo.
    echo Para crear el repositorio, ve a:
    echo https://github.com/new
    echo.
    pause
)
