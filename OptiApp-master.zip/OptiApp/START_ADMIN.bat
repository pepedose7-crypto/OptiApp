@echo off
REM OptiApp Admin Launcher
REM Automatically requests admin privileges if not running as admin

REM Check if already running as admin
net session >nul 2>&1
if %errorLevel% equ 0 (
    REM Already admin, run the app directly
    cd /d "%~dp0"
    powershell -Command "Unblock-File -Path '.\OptiApp.exe'" 2>nul
    start OptiApp.exe
    exit /b 0
) else (
    REM Not admin, request elevation via PowerShell
    powershell -Command "Start-Process cmd -ArgumentList '/c cd /d %cd% ^& powershell -Command \"Unblock-File -Path \".\\OptiApp.exe\"\" 2^>nul ^& start OptiApp.exe' -Verb RunAs" 2>nul
    exit /b 0
)
